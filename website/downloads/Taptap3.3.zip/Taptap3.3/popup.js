// POPUP.JS

const SERVER_URL =
    "https://license-server-lewp.onrender.com";

const EMAIL_REGEX =
    /^[a-zA-Z0-9._%+-]{1,64}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;


let storage = {};
let selectedTokens = 0;
let pollTimer = null;


// ============================================================
// MESSAGE HELPER
// ============================================================

const sendMessageWithRetry = (msg) => {

    return new Promise((resolve) => {

        chrome.runtime.sendMessage(
            msg,
            (response) => {

                if (chrome.runtime.lastError) {

                    console.warn(
                        "Retrying connection..."
                    );

                    setTimeout(
                        () =>
                            resolve(
                                sendMessageWithRetry(msg)
                            ),
                        500
                    );

                } else {

                    resolve(response);
                }
            }
        );
    });
};


// ============================================================
// REFRESH SETTINGS
// ============================================================

const MIN_REFRESH_SECONDS = 10;
const MAX_REFRESH_SECONDS = 86400;


function getRefreshElements() {

    return {
        enabled:
            document.getElementById(
                "auto-refresh-enabled"
            ),

        value:
            document.getElementById(
                "refresh-interval-value"
            ),

        unit:
            document.getElementById(
                "refresh-interval-unit"
            ),

        save:
            document.getElementById(
                "save-refresh-btn"
            ),

        status:
            document.getElementById(
                "refresh-status"
            )
    };
}


function convertToSeconds(value, unit) {

    const number =
        Number(value);

    if (!Number.isFinite(number)) {
        return 0;
    }

    if (unit === "seconds") {
        return number;
    }

    if (unit === "minutes") {
        return number * 60;
    }

    if (unit === "hours") {
        return number * 60 * 60;
    }

    return number;
}


function secondsToDisplay(seconds) {

    if (seconds % 3600 === 0) {

        return {
            value: seconds / 3600,
            unit: "hours"
        };
    }

    if (seconds % 60 === 0) {

        return {
            value: seconds / 60,
            unit: "minutes"
        };
    }

    return {
        value: seconds,
        unit: "seconds"
    };
}


async function loadRefreshSettings() {

    const elements =
        getRefreshElements();

    if (
        !elements.enabled ||
        !elements.value ||
        !elements.unit
    ) {
        return;
    }


    const settings =
        await chrome.storage.local.get([
            "autoRefreshEnabled",
            "refreshIntervalMs"
        ]);


    const enabled =
        settings.autoRefreshEnabled === true;


    const intervalMs =
        Number(
            settings.refreshIntervalMs
        ) ||
        5 * 60 * 1000;


    const seconds =
        Math.max(
            MIN_REFRESH_SECONDS,
            Math.min(
                MAX_REFRESH_SECONDS,
                Math.round(
                    intervalMs / 1000
                )
            )
        );


    const display =
        secondsToDisplay(seconds);


    elements.enabled.checked =
        enabled;

    elements.value.value =
        display.value;

    elements.unit.value =
        display.unit;


    updateRefreshStatusText(
        enabled,
        seconds
    );
}


function updateRefreshStatusText(
    enabled,
    seconds
) {

    const elements =
        getRefreshElements();

    if (!elements.status) {
        return;
    }


    if (!enabled) {

        elements.status.textContent =
            "Auto refresh is OFF";

        elements.status.style.color =
            "#94a3b8";

        return;
    }


    const display =
        secondsToDisplay(seconds);


    elements.status.textContent =
        `Auto refresh: every ${display.value} ${display.unit}`;


    elements.status.style.color =
        "rgb(62, 207, 142)";
}


async function saveRefreshSettings() {

    const elements =
        getRefreshElements();


    if (
        !elements.enabled ||
        !elements.value ||
        !elements.unit
    ) {
        return;
    }


    let value =
        Number(
            elements.value.value
        );


    if (
        !Number.isFinite(value) ||
        value <= 0
    ) {

        alert(
            "Please enter a valid refresh interval."
        );

        return;
    }


    let seconds =
        convertToSeconds(
            value,
            elements.unit.value
        );


    // Minimum 10 seconds.
    if (seconds < MIN_REFRESH_SECONDS) {

        seconds =
            MIN_REFRESH_SECONDS;

        const display =
            secondsToDisplay(seconds);

        elements.value.value =
            display.value;

        elements.unit.value =
            display.unit;
    }


    // Maximum 24 hours.
    if (seconds > MAX_REFRESH_SECONDS) {

        seconds =
            MAX_REFRESH_SECONDS;

        const display =
            secondsToDisplay(seconds);

        elements.value.value =
            display.value;

        elements.unit.value =
            display.unit;
    }


    const enabled =
        elements.enabled.checked;


    const intervalMs =
        seconds * 1000;


    await chrome.storage.local.set({
        autoRefreshEnabled:
            enabled,

        refreshIntervalMs:
            intervalMs
    });


    updateRefreshStatusText(
        enabled,
        seconds
    );


    const saveButton =
        elements.save;


    if (saveButton) {

        const original =
            saveButton.textContent;

        saveButton.textContent =
            "Saved";

        setTimeout(() => {

            saveButton.textContent =
                original || "Save";

        }, 1500);
    }


    // Tell the currently active tab to immediately
    // use the new settings.
    try {

        const tabs =
            await chrome.tabs.query({
                active: true,
                currentWindow: true
            });


        const tab =
            tabs[0];


        if (
            tab &&
            tab.id &&
            tab.url &&
            tab.url.includes(
                "gamemania.co.ke"
            )
        ) {

            chrome.tabs.sendMessage(
                tab.id,
                {
                    action:
                        "REFRESH_SETTINGS_UPDATED"
                },
                () => {
                    // Ignore if content script isn't available.
                    void chrome.runtime.lastError;
                }
            );
        }

    } catch (err) {

        console.warn(
            "Could not notify active tab:",
            err
        );
    }
}


// ============================================================
// INITIALIZATION
// ============================================================

document.addEventListener(
    "DOMContentLoaded",
    async () => {

        storage =
            await chrome.storage.local.get([
                "deviceId",
                "lastPhone"
            ]);


        const emailInput =
            document.getElementById(
                "userEmailInput"
            );


        const syncMsg =
            document.getElementById(
                "sync-message"
            );


        // ------------------------------------------------------
        // Existing account handling
        // ------------------------------------------------------

        if (
            storage.deviceId &&
            storage.deviceId.includes("@")
        ) {

            emailInput.value =
                storage.deviceId;

            syncMsg.textContent =
                "Profile Linked & syncd!";

            syncMsg.style.color =
                "rgb(62, 207, 142)";

            await updateUI();

        } else {

            syncMsg.textContent =
                "Please set an email to activate monitoring.";

            syncMsg.style.color =
                "#FFBF00";

            document.getElementById(
                "balance-val"
            ).textContent = "0";

            setUIElementsToColor(
                "#991b1b"
            );
        }


        if (storage.lastPhone) {

            document.getElementById(
                "phone-input"
            ).value =
                storage.lastPhone;
        }


        // ------------------------------------------------------
        // Load refresh settings
        // ------------------------------------------------------

        await loadRefreshSettings();


        const refreshElements =
            getRefreshElements();


        if (refreshElements.save) {

            refreshElements.save.onclick =
                saveRefreshSettings;
        }


        // ------------------------------------------------------
        // Save / Link Email
        // ------------------------------------------------------

        document.getElementById(
            "saveEmailBtn"
        ).onclick = async () => {

            const inputEmail =
                emailInput.value
                    .trim()
                    .toLowerCase();


            if (
                !EMAIL_REGEX.test(
                    inputEmail
                )
            ) {

                syncMsg.textContent =
                    "Please enter a valid email address.";

                syncMsg.style.color =
                    "#991b1b";

                return;
            }


            syncMsg.textContent =
                "Connecting profile...";

            syncMsg.style.color =
                "#94a3b8";


            await chrome.storage.local.set({
                deviceId:
                    inputEmail
            });


            storage.deviceId =
                inputEmail;


            try {

                const response =
                    await fetch(
                        `${SERVER_URL}/api/v1/register`,
                        {
                            method: "POST",

                            headers: {
                                "Content-Type":
                                    "application/json"
                            },

                            body: JSON.stringify({
                                device_id:
                                    inputEmail
                            })
                        }
                    );


                if (!response.ok) {

                    throw new Error(
                        "Registration failed."
                    );
                }


                syncMsg.textContent =
                    "Success! Click the blue Top Up button to pick a package";

                syncMsg.style.color =
                    "rgb(62, 207, 142)";


                setTimeout(() => {

                    syncMsg.textContent =
                        "Then paste your email into your other profiles to sync";

                }, 5000);


                chrome.runtime.sendMessage({
                    action:
                        "SYNC_IDENTITY_CONTEXT"
                });


                chrome.runtime.sendMessage({
                    action:
                        "RESET_BLOCK"
                });


                await updateUI();

            } catch (err) {

                console.error(
                    "Account identity matching pipeline link error:",
                    err
                );


                syncMsg.textContent =
                    "Network synchronization failed.";

                syncMsg.style.color =
                    "#991b1b";
            }
        };


        // ------------------------------------------------------
        // Info
        // ------------------------------------------------------

        document.getElementById(
            "info-icon"
        ).onclick = () => {

            const modal =
                document.getElementById(
                    "info-modal"
                );


            modal.style.display =
                modal.style.display === "block"
                    ? "none"
                    : "block";
        };


        // ------------------------------------------------------
        // Help
        // ------------------------------------------------------

        document.getElementById(
            "help-link"
        ).onclick = () => {

            const identity =
                storage.deviceId ||
                "UNSET";


            const message =
                encodeURIComponent(
                    `What's up Tapper, apologies for the inconvenience. To contact Admin please proceed to whatsapp and air your predicament. User Account: ${identity}`
                );


            window.open(
                `https://wa.me/254725766022?text=${message}`,
                "_blank"
            );
        };


        // ------------------------------------------------------
        // FAQ
        // ------------------------------------------------------

        const faqHeaders =
            document.querySelectorAll(
                ".faq-header"
            );


        faqHeaders.forEach(
            (header) => {

                header.style.cursor =
                    "pointer";


                header.addEventListener(
                    "click",
                    () => {

                        const parent =
                            header.parentElement;


                        const dropdown =
                            parent.querySelector(
                                ".dropdown"
                            );


                        const icon =
                            header.querySelector(
                                ".icon"
                            );


                        if (dropdown) {

                            const isHidden =
                                window.getComputedStyle(
                                    dropdown
                                ).display === "none";


                            dropdown.style.display =
                                isHidden
                                    ? "block"
                                    : "none";


                            icon.textContent =
                                isHidden
                                    ? "▲"
                                    : "▼";
                        }
                    }
                );
            }
        );


        // ------------------------------------------------------
        // Top Up
        // ------------------------------------------------------

        document.getElementById(
            "topup-toggle-btn"
        ).onclick = () => {

            if (
                !storage.deviceId ||
                !storage.deviceId.includes("@")
            ) {

                alert(
                    "Please save a valid email account before attempting to top up."
                );

                return;
            }


            document.getElementById(
                "topup-menu"
            ).style.display =
                "grid";
        };


        document.getElementById(
            "topup-menu"
        ).addEventListener(
            "click",
            (e) => {

                const card =
                    e.target.closest(
                        ".token-opt"
                    );


                if (!card) return;


                selectedTokens =
                    parseInt(
                        card.dataset.value
                    );


                document.getElementById(
                    "topup-menu"
                ).style.display =
                    "none";


                document.getElementById(
                    "topup-input-container"
                ).style.display =
                    "block";
            }
        );


        // ------------------------------------------------------
        // STK
        // ------------------------------------------------------

        document.getElementById(
            "submit-stk"
        ).onclick = async () => {

            const btn =
                document.getElementById(
                    "submit-stk"
                );


            const msg =
                document.getElementById(
                    "tx-message"
                );


            let phone =
                document.getElementById(
                    "phone-input"
                ).value
                    .replace(/\D/g, "");


            if (phone.startsWith("0")) {

                phone =
                    "254" +
                    phone.substring(1);

            } else if (
                phone.length === 9
            ) {

                phone =
                    "254" +
                    phone;
            }


            btn.disabled = true;


            msg.style.display =
                "block";


            msg.textContent =
                "Processing request.. Plz check your phone.";


            chrome.storage.local.set({
                lastPhone:
                    phone
            });


            const res =
                await sendMessageWithRetry({
                    action:
                        "TRIGGER_STK",

                    payload: {
                        device_id:
                            storage.deviceId,

                        phone_number:
                            phone,

                        tokens:
                            selectedTokens
                    }
                });


            btn.disabled = false;


            if (res?.success) {

                pollForTokenUpdate();

            } else {

                msg.textContent =
                    "Error initiating payment.";
            }
        };
    }
);


// ============================================================
// PAYMENT POLLING
// ============================================================

function pollForTokenUpdate() {

    if (pollTimer) {
        clearInterval(pollTimer);
    }


    pollTimer =
        setInterval(
            async () => {

                const paymentStatus =
                    await updateUI();


                const msg =
                    document.getElementById(
                        "tx-message"
                    );


                if (
                    paymentStatus ===
                    "SUCCESS"
                ) {

                    clearInterval(
                        pollTimer
                    );


                    msg.textContent =
                        "Success!";


                    document.getElementById(
                        "topup-input-container"
                    ).style.display =
                        "none";


                    chrome.tabs.query(
                        {
                            active: true,
                            currentWindow: true
                        },

                        (tabs) => {

                            if (tabs[0]) {

                                chrome.tabs.sendMessage(
                                    tabs[0].id,

                                    {
                                        action:
                                            "RESET_BLOCK"
                                    },

                                    () => {
                                        void chrome.runtime.lastError;
                                    }
                                );
                            }
                        }
                    );


                } else if (
                    paymentStatus ===
                    "FAILED"
                ) {

                    clearInterval(
                        pollTimer
                    );


                    msg.textContent =
                        "Transaction cancelled or failed.";
                }

            },
            4000
        );
}


// ============================================================
// UI COLORS
// ============================================================

function setUIElementsToColor(color) {

    [
        "balance-val",
        "topup-toggle-btn",
        "status-badge",
        "submit-stk",
        "activateBtn"
    ].forEach(
        (id) => {

            const el =
                document.getElementById(
                    id
                );


            if (!el) return;


            el.style.color =
                id === "balance-val"
                    ? color
                    : (
                        id === "topup-toggle-btn" ||
                        id === "submit-stk" ||
                        id === "activateBtn"
                    )
                        ? ""
                        : color;


            if (
                id === "topup-toggle-btn" ||
                id === "submit-stk" ||
                id === "activateBtn"
            ) {

                el.style.backgroundColor =
                    color;
            }
        }
    );


    const badge =
        document.getElementById(
            "status-badge"
        );


    const actBtn =
        document.getElementById(
            "activateBtn"
        );


    badge.textContent =
        "INACTIVE";


    actBtn.textContent =
        "Top up to run";


    actBtn.disabled =
        true;


    const liveDot =
        document.getElementById(
            "live-dot"
        );


    if (liveDot) {

        liveDot.className =
            "live-dot red";
    }
}


// ============================================================
// UPDATE UI
// ============================================================

async function updateUI() {

    if (
        !storage.deviceId ||
        !storage.deviceId.includes("@")
    ) {

        return "NONE";
    }


    try {

        const res =
            await fetch(
                `${SERVER_URL}/api/v1/status?device_id=${storage.deviceId}`
            );


        if (!res.ok) {
            return "NONE";
        }


        const data =
            await res.json();


        document.getElementById(
            "online-users"
        ).textContent =
            data.online_users ?? 0;


        const t =
            data.token_balance || 0;


        document.getElementById(
            "balance-val"
        ).textContent =
            t;


        let color =
            t === 0
                ? "#991b1b"
                : (
                    t < 4
                        ? "#FFBF00"
                        : "rgb(62, 207, 142)"
                );


        [
            "balance-val",
            "topup-toggle-btn",
            "status-badge",
            "submit-stk",
            "activateBtn"
        ].forEach(
            (id) => {

                const el =
                    document.getElementById(
                        id
                    );


                if (!el) return;


                el.style.color =
                    id === "balance-val"
                        ? color
                        : (
                            id === "topup-toggle-btn" ||
                            id === "submit-stk" ||
                            id === "activateBtn"
                        )
                            ? ""
                            : color;


                if (
                    id === "topup-toggle-btn" ||
                    id === "submit-stk" ||
                    id === "activateBtn"
                ) {

                    el.style.backgroundColor =
                        color;
                }
            }
        );


        const badge =
            document.getElementById(
                "status-badge"
            );


        const actBtn =
            document.getElementById(
                "activateBtn"
            );


        const liveDot =
            document.getElementById(
                "live-dot"
            );


        if (t === 0) {

            badge.textContent =
                "INACTIVE";


            actBtn.textContent =
                "Top up to run";


            actBtn.disabled =
                true;


            liveDot.className =
                "live-dot red";


        } else if (t < 4) {

            badge.textContent =
                "Monitoring...";


            actBtn.textContent =
                "Running";


            actBtn.disabled =
                false;


            liveDot.className =
                "live-dot yellow";


        } else {

            badge.textContent =
                "ACTIVE";


            actBtn.textContent =
                "Running";


            actBtn.disabled =
                false;


            liveDot.className =
                "live-dot green";
        }


        return (
            data.latest_payment_status ||
            "NONE"
        );

    } catch (err) {

        console.error(
            "UI Update Failed:",
            err
        );

        return "NONE";
    }
}