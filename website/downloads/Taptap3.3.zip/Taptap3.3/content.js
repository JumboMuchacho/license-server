// CONTENT.JS
const SERVER_URL = "https://license-server-lewp.onrender.com";

let alarmInterval = null;
let alarmSafetyTimeout = null;
let refreshTimer = null;
let isSpeakingOrPlaying = false;
let userHasInteracted = false;
let cachedLabels = null;

const inFlightTransactions = new Set();

// ============================================================
// AUDIO INTERACTION
// ============================================================

function unlockAudio() {
    userHasInteracted = true;

    console.log("Audio unlocked: user interaction detected.");

    document.removeEventListener("click", unlockAudio);
    document.removeEventListener("keydown", unlockAudio);
    document.removeEventListener("touchstart", unlockAudio);
}

document.addEventListener("click", unlockAudio);
document.addEventListener("keydown", unlockAudio);
document.addEventListener("touchstart", unlockAudio);


// ============================================================
// MESSAGE HELPER
// ============================================================

function safeSendMessage(msg, timeoutMs = 10000) {
    return new Promise((resolve) => {
        if (!chrome.runtime?.id) {
            console.warn("Extension context invalidated.");
            resolve(null);
            return;
        }

        let settled = false;
        let timeoutId = null;

        const finish = (value) => {
            if (settled) return;

            settled = true;

            if (timeoutId) {
                clearTimeout(timeoutId);
            }

            resolve(value);
        };

        timeoutId = setTimeout(() => {
            console.warn(`Message timed out: ${msg.action}`);
            finish(null);
        }, timeoutMs);

        try {
            chrome.runtime.sendMessage(msg, (response) => {
                if (chrome.runtime.lastError) {
                    console.warn(
                        `Message failed (${msg.action}):`,
                        chrome.runtime.lastError.message
                    );

                    finish(null);
                    return;
                }

                finish(response);
            });
        } catch (err) {
            console.error(`Message exception (${msg.action}):`, err);
            finish(null);
        }
    });
}


// ============================================================
// HEARTBEAT
// ============================================================

async function sendHeartbeat() {
    try {
        const store = await chrome.storage.local.get("deviceId");

        if (!store.deviceId) return;

        await fetch(`${SERVER_URL}/api/v1/heartbeat`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                device_id: store.deviceId
            })
        });
    } catch (err) {
        if (
            err.message &&
            err.message.includes("Extension context invalidated")
        ) {
            return;
        }

        console.error("Heartbeat failed:", err);
    }
}

sendHeartbeat();

setInterval(sendHeartbeat, 120000);


// ============================================================
// PAGE TARGETING
// ============================================================

function getStableElement(labelText) {
    const items = document.querySelectorAll(".item");

    for (const item of items) {
        const left = item.querySelector(".left");

        if (left && left.textContent.includes(labelText)) {
            return item.querySelector(".right");
        }
    }

    return null;
}


// ============================================================
// ALARM
// ============================================================

function stopAlarmLoop(reason = "stopped") {
    if (alarmInterval) {
        clearInterval(alarmInterval);
        alarmInterval = null;
    }

    if (alarmSafetyTimeout) {
        clearTimeout(alarmSafetyTimeout);
        alarmSafetyTimeout = null;
    }

    isSpeakingOrPlaying = false;

    console.log(`Alarm ${reason}.`);

    // Restart refresh scheduling after alarm finishes.
    schedulePageRefresh();
}


function startAlarmLoop() {
    // Never start twice.
    if (alarmInterval) return;

    const playAlert = () => {
        if (!userHasInteracted) {
            console.warn(
                "Alarm silent: waiting for user interaction on page..."
            );

            return;
        }

        if (isSpeakingOrPlaying) return;

        isSpeakingOrPlaying = true;

        const audio = new Audio(
            chrome.runtime.getURL("alarm.mp3")
        );

        audio.onended = () => {
            isSpeakingOrPlaying = false;
            audio.remove();
        };

        audio.onerror = () => {
            isSpeakingOrPlaying = false;
            audio.remove();
        };

        audio.play().catch((err) => {
            console.error("Audio playback error:", err);

            isSpeakingOrPlaying = false;

            audio.remove();
        });
    };

    playAlert();

    // Repeat alarm every 8 seconds.
    alarmInterval = setInterval(playAlert, 8000);

    // Maximum alarm duration: 60 seconds.
    alarmSafetyTimeout = setTimeout(() => {
        stopAlarmLoop(
            "automatically stopped after 60 seconds"
        );
    }, 60000);
}


// ============================================================
// AUTO REFRESH
// ============================================================

const DEFAULT_REFRESH_INTERVAL = 5 * 60 * 1000;

// Minimum allowed refresh interval = 10 seconds.
const MIN_REFRESH_INTERVAL = 10 * 1000;

// Maximum allowed refresh interval = 24 hours.
const MAX_REFRESH_INTERVAL = 24 * 60 * 60 * 1000;


function normalizeRefreshInterval(value) {
    let interval = Number(value);

    if (!Number.isFinite(interval)) {
        interval = DEFAULT_REFRESH_INTERVAL;
    }

    interval = Math.max(
        MIN_REFRESH_INTERVAL,
        Math.min(MAX_REFRESH_INTERVAL, interval)
    );

    return interval;
}


async function schedulePageRefresh() {
    try {
        if (refreshTimer) {
            clearTimeout(refreshTimer);
            refreshTimer = null;
        }

        const settings = await chrome.storage.local.get([
            "autoRefreshEnabled",
            "refreshIntervalMs"
        ]);

        const enabled = settings.autoRefreshEnabled === true;

        if (!enabled) {
            console.log("Auto refresh is disabled.");
            return;
        }

        const interval = normalizeRefreshInterval(
            settings.refreshIntervalMs
        );

        console.log(
            `Auto refresh scheduled in ${Math.round(interval / 1000)} seconds.`
        );

        refreshTimer = setTimeout(async () => {

            // Never refresh while the alarm is actively running.
            if (alarmInterval || isSpeakingOrPlaying) {
                console.log(
                    "Alarm currently active. Delaying page refresh."
                );

                schedulePageRefresh();
                return;
            }

            console.log("Auto refreshing monitored webpage...");

            try {
                window.location.reload();
            } catch (err) {
                console.error(
                    "Unable to refresh webpage:",
                    err
                );

                schedulePageRefresh();
            }

        }, interval);

    } catch (err) {
        console.error(
            "Unable to schedule page refresh:",
            err
        );
    }
}


// ============================================================
// REFRESH STORAGE CHANGES
// ============================================================

chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== "local") return;

    if (
        changes.autoRefreshEnabled ||
        changes.refreshIntervalMs
    ) {
        console.log(
            "Refresh settings changed. Rescheduling..."
        );

        schedulePageRefresh();
    }
});


// ============================================================
// MESSAGE LISTENER FOR REFRESH CONTROL
// ============================================================

chrome.runtime.onMessage.addListener(
    (request, sender, sendResponse) => {

        if (request.action === "REFRESH_NOW") {

            if (alarmInterval || isSpeakingOrPlaying) {
                sendResponse({
                    success: false,
                    message: "Alarm currently active."
                });

                return;
            }

            try {
                window.location.reload();

                sendResponse({
                    success: true
                });

            } catch (err) {

                sendResponse({
                    success: false,
                    message: err.message
                });
            }

            return true;
        }

        if (request.action === "GET_REFRESH_STATUS") {

            chrome.storage.local.get([
                "autoRefreshEnabled",
                "refreshIntervalMs"
            ]).then((settings) => {

                sendResponse({
                    success: true,
                    enabled:
                        settings.autoRefreshEnabled === true,

                    intervalMs:
                        normalizeRefreshInterval(
                            settings.refreshIntervalMs
                        )
                });

            });

            return true;
        }
    }
);


// ============================================================
// TRANSACTION MONITORING
// ============================================================

async function checkForTargetPopup() {

    if (!chrome.runtime?.id) return;

    try {

        const store =
            await chrome.storage.local.get("deviceId");

        if (!store.deviceId) return;


        // --------------------------------------------------------
        // Fetch targeting rules once per page session.
        // --------------------------------------------------------

        if (!cachedLabels) {

            const ruleData =
                await safeSendMessage({
                    action: "FETCH_RULES"
                });

            if (!ruleData) {

                console.warn(
                    "Unable to obtain server rules."
                );

                return;
            }

            cachedLabels =
                ruleData.labels || {
                    orderLabel: "Order Number",
                    timeLabel: "Create Time"
                };
        }


        // --------------------------------------------------------
        // Find transaction elements.
        // --------------------------------------------------------

        const orderEl =
            getStableElement(
                cachedLabels.orderLabel
            );

        const timeEl =
            getStableElement(
                cachedLabels.timeLabel
            );

        if (!orderEl || !timeEl) return;


        const orderNumber =
            orderEl.textContent.trim();

        const fullTime =
            timeEl.textContent.trim();


        // Ignore placeholders.
        if (!/^\d+$/.test(orderNumber)) {
            return;
        }


        // Require HH:MM:SS.
        const timeMatch =
            fullTime.match(/\d{2}:\d{2}:\d{2}/);

        if (!timeMatch) return;


        const timeOnly =
            timeMatch[0].replace(/:/g, "");

        const txnId =
            `${orderNumber}_${timeOnly}`;


        // --------------------------------------------------------
        // Check local successful transactions.
        // --------------------------------------------------------

        const processedData =
            await chrome.storage.local.get(
                "processed_orders"
            );

        const processedOrders =
            processedData.processed_orders || [];


        if (processedOrders.includes(txnId)) {
            return;
        }


        // --------------------------------------------------------
        // Prevent duplicate simultaneous requests.
        // --------------------------------------------------------

        if (inFlightTransactions.has(txnId)) {
            return;
        }

        inFlightTransactions.add(txnId);


        try {

            console.log(
                "New transaction detected:",
                txnId
            );

            console.log(
                "Requesting server token authorization..."
            );


            // ----------------------------------------------------
            // IMPORTANT:
            //
            // The alarm DOES NOT start here.
            //
            // Server must first authorize and consume a token.
            // ----------------------------------------------------

            const chargeRes =
                await safeSendMessage(
                    {
                        action:
                            "CONSUME_TOKEN_SIGNAL",

                        payload: {
                            txn_id: txnId,
                            device_id:
                                store.deviceId
                        }
                    },

                    10000
                );


            // ----------------------------------------------------
            // Server unavailable.
            // ----------------------------------------------------

            if (!chargeRes) {

                console.warn(
                    "Token authorization unavailable."
                );

                console.warn(
                    "Alarm will NOT sound."
                );

                return;
            }


            // ----------------------------------------------------
            // Server authorization.
            // ----------------------------------------------------

            const authorized =
                chargeRes.success === true ||
                chargeRes.message === "Already paid";


            if (!authorized) {

                console.log(
                    "Server did not authorize transaction.",
                    chargeRes.message || chargeRes
                );

                console.log(
                    "Alarm will NOT sound."
                );

                return;
            }


            // ----------------------------------------------------
            // TOKEN AUTHORIZED.
            // ----------------------------------------------------

            console.log(
                "Server authorized transaction."
            );

            console.log(
                "Starting alarm."
            );


            // ----------------------------------------------------
            // Mark transaction processed.
            // ----------------------------------------------------

            if (!processedOrders.includes(txnId)) {

                processedOrders.push(txnId);

                const MAX_PROCESSED_ORDERS = 500;

                const trimmedOrders =
                    processedOrders.length >
                    MAX_PROCESSED_ORDERS

                        ? processedOrders.slice(
                            -MAX_PROCESSED_ORDERS
                        )

                        : processedOrders;


                await chrome.storage.local.set({
                    processed_orders:
                        trimmedOrders
                });
            }


            // ----------------------------------------------------
            // ONLY NOW start alarm.
            // ----------------------------------------------------

            startAlarmLoop();

        } finally {

            inFlightTransactions.delete(txnId);
        }

    } catch (err) {

        if (
            err.message &&
            !err.message.includes(
                "Extension context invalidated"
            )
        ) {

            console.error(
                "Monitor Error:",
                err
            );
        }
    }
}


// ============================================================
// MUTATION OBSERVER
// ============================================================

const observer =
    new MutationObserver(() => {
        checkForTargetPopup();
    });


if (document.body) {

    observer.observe(
        document.body,
        {
            childList: true,
            subtree: true,
            characterData: true
        }
    );
}


// Initial check.
checkForTargetPopup();


// Start auto-refresh scheduling.
schedulePageRefresh();


// Keep user online.
sendHeartbeat();

setInterval(
    sendHeartbeat,
    120000
);