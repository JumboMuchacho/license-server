// BACKGROUND.JS
const SERVER_URL = "https://license-server-lewp.onrender.com";

function isValidEmail(email) {
    if (!email || typeof email !== "string") return false;

    const emailRegex =
        /^[a-zA-Z0-9._%+-]{1,64}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    return emailRegex.test(email);
}

async function fetchRulesFromServer() {
    try {
        const store = await chrome.storage.local.get("deviceId");
        if (!store.deviceId || !isValidEmail(store.deviceId)) {
            return { rules: [], token_balance: 0 };
        }

        const response = await fetch(`${SERVER_URL}/api/v1/rules`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ device_id: store.deviceId })
        });
        
        if (!response.ok) return { rules: [], token_balance: 0 };
        return await response.json();
    } catch (err) {
        return { rules: [], token_balance: 0 };
    }
}

async function consumeTokenOnServer(txnId, providedDeviceId) {
    try {
        const store = await chrome.storage.local.get("deviceId");
        const deviceId = providedDeviceId || store.deviceId;

        // --- SECURITY HARDENING: Validate Identity ---
        if (!deviceId || !isValidEmail(deviceId)) {
            console.error("Consumption aborted: Invalid device_id");
            return { success: false, message: "Invalid email format or length" };
        }

        // --- SECURITY HARDENING: Sanitize txnId ---
        const sanitizedTxnId = txnId ? txnId.replace(/[^a-zA-Z0-9_-]/g, "") : "";

        const response = await fetch(`${SERVER_URL}/api/v1/billing/consume-token`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                device_id: deviceId,
                txn_id: sanitizedTxnId
            })
        });

        return await response.json();
    } catch (err) {
        console.error("Unable to contact server:", err);
        return { success: false, message: "Network error" };
    }
}

// --- CENTRAL EXTENSION MESSAGE PIPELINE ---

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    
    if (request.action === "FETCH_RULES") {
        fetchRulesFromServer().then(data => {
            sendResponse(data);
        });
        return true; 
    }

    if (request.action === "CONSUME_TOKEN_SIGNAL") {
        consumeTokenOnServer(request.payload.txn_id, request.payload.device_id).then(data => {
            sendResponse(data);
        });
        return true;
    }
    
    if (request.action === "TRIGGER_STK") {
        (async () => {
            try {
                const store = await chrome.storage.local.get("deviceId");
                if (!store.deviceId || !isValidEmail(store.deviceId)) {
                    throw new Error("Invalid account identity.");
                }
                
                const res = await fetch(`${SERVER_URL}/api/v1/mpesa/stkpush`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        device_id: request.payload.device_id,
                        phone_number: request.payload.phone_number,
                        tokens: request.payload.tokens
                    })
                });
                
                let data = {};

                try {
                    data = await res.json();
                } catch {
                    data = {};
                }
                sendResponse({ success: res.ok, data: data });
            } catch (err) {
                console.error("STK Pipeline tracking exception:", err);
                sendResponse({ success: false, error: err.message });
            }
        })();
        return true; 
    }
});
