// POPUP>JS
const SERVER_URL = "https://license-server-lewp.onrender.com";
const EMAIL_REGEX =
    /^[a-zA-Z0-9._%+-]{1,64}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
let storage = {}, selectedTokens = 0;
let pollTimer = null;

const sendMessageWithRetry = (msg) => {
    return new Promise((resolve) => {
        chrome.runtime.sendMessage(msg, (response) => {
            if (chrome.runtime.lastError) {
                console.warn("Retrying connection...");
                setTimeout(() => resolve(sendMessageWithRetry(msg)), 500);
            } else {
                resolve(response);
            }
        });
    });
};

document.addEventListener("DOMContentLoaded", async () => {
    // Read cached tracking elements from extension local memory assets
    storage = await chrome.storage.local.get(["deviceId", "lastPhone"]);

    const emailInput = document.getElementById("userEmailInput");
    const syncMsg = document.getElementById("sync-message");

    // Populate the input field if an email (stored in deviceId) already exists
    if (storage.deviceId && storage.deviceId.includes("@")) {
        emailInput.value = storage.deviceId;
        syncMsg.textContent = "Profile Linked & syncd!";
        syncMsg.style.color = "rgb(62, 207, 142)";
        await updateUI();
    } else {
        syncMsg.textContent = "Please set an email to activate monitoring.";
        syncMsg.style.color = "#FFBF00";
        document.getElementById("balance-val").textContent = "0";
        setUIElementsToColor("#991b1b");
    }

    if (storage.lastPhone) document.getElementById("phone-input").value = storage.lastPhone;

    // --- Save/Link Email Handler Logic ---
    document.getElementById("saveEmailBtn").onclick = async () => {
        const inputEmail = emailInput.value.trim().toLowerCase();

        const emailRegex =
            /^[a-zA-Z0-9._%+-]{1,64}@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (!EMAIL_REGEX.test(inputEmail)) {
            syncMsg.textContent = "Please enter a valid email address.";
            syncMsg.style.color = "#991b1b";
            return;
        }

        syncMsg.textContent = "Connecting profile...";
        syncMsg.style.color = "#94a3b8";

        // Save the email into the persistent local storage row
        await chrome.storage.local.set({ deviceId: inputEmail });
        storage.deviceId = inputEmail;

        // Force backend to register this email account if it is a completely new user
        try {
            const response = await fetch(`${SERVER_URL}/api/v1/register`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    device_id: inputEmail
                })
            });

            if (!response.ok) {
                throw new Error("Registration failed.");
            }

            syncMsg.textContent = "Account successfully linked!";
            syncMsg.style.color = "rgb(62, 207, 142)";
            
            // Notify background automation tasks to refresh rules frames under the new email signature
            chrome.runtime.sendMessage({ action: "SYNC_IDENTITY_CONTEXT" });
            chrome.runtime.sendMessage({ action: "RESET_BLOCK" });
            
            await updateUI();
        } catch (err) {
            console.error("Account identity matching pipeline link error:", err);
            syncMsg.textContent = "Network synchronization failed.";
            syncMsg.style.color = "#991b1b";
        }
    };

    // --- Original Event Observers Restored Unchanged ---
    document.getElementById("info-icon").onclick = () => {
        const modal = document.getElementById("info-modal");
        modal.style.display = (modal.style.display === "block") ? "none" : "block";
    };

    document.getElementById("help-link").onclick = () => {
        const identity = storage.deviceId || "UNSET";
        const message = encodeURIComponent(`What's up Tapper, apologies for the inconvenience. To contact Admin please proceed to whatsapp and air your predicament. User Account: ${identity}`);
        window.open(`https://wa.me/254725766022?text=${message}`, '_blank');
    };

    const faqHeaders = document.querySelectorAll(".faq-header");
    faqHeaders.forEach(header => {
        header.style.cursor = "pointer";
        header.addEventListener("click", () => {
            const parent = header.parentElement;
            const dropdown = parent.querySelector(".dropdown");
            const icon = header.querySelector(".icon");
            if (dropdown) {
                const isHidden = window.getComputedStyle(dropdown).display === "none";
                dropdown.style.display = isHidden ? "block" : "none";
                icon.textContent = isHidden ? "▲" : "▼";
            }
        });
    });

    document.getElementById("topup-toggle-btn").onclick = () => {
        if (!storage.deviceId || !storage.deviceId.includes("@")) {
            alert("Please save a valid email account before attempting to top up.");
            return;
        }
        document.getElementById("topup-menu").style.display = "grid";
    };
    
    document.getElementById("topup-menu").addEventListener("click", (e) => {
        const card = e.target.closest(".token-opt");

        if (!card) return;

        selectedTokens = parseInt(card.dataset.value);

        document.getElementById("topup-menu").style.display = "none";
        document.getElementById("topup-input-container").style.display = "block";
    });

    document.getElementById("submit-stk").onclick = async () => {
        const btn = document.getElementById("submit-stk");
        const msg = document.getElementById("tx-message");
        let phone = document.getElementById("phone-input").value.replace(/\D/g, '');
        if (phone.startsWith('0')) phone = '254' + phone.substring(1);
        else if (phone.length === 9) phone = '254' + phone;

        btn.disabled = true;
        msg.style.display = "block";
        msg.textContent = "Processing request.. Plz check your phone.";
        chrome.storage.local.set({ lastPhone: phone });
        
        const res = await sendMessageWithRetry({ 
            action: "TRIGGER_STK", 
            payload: {
                device_id: storage.deviceId,
                phone_number: phone,
                tokens: selectedTokens
            } 
        });

        btn.disabled = false;
        if (res?.success) {
            pollForTokenUpdate();
        } else {
            msg.textContent = "Error initiating payment.";
        }
    };
});

function pollForTokenUpdate() {
    if (pollTimer) clearInterval(pollTimer);

    pollTimer = setInterval(async () => {
        const paymentStatus = await updateUI();
        const msg = document.getElementById("tx-message");

        if (paymentStatus === "SUCCESS") {
            clearInterval(pollTimer);
            msg.textContent = "Success!";
            document.getElementById("topup-input-container").style.display = "none";
            chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
                if (tabs[0]) chrome.tabs.sendMessage(tabs[0].id, { action: "RESET_BLOCK" });
            });
        } 
        else if (paymentStatus === "FAILED") {
            clearInterval(pollTimer);
            msg.textContent = "Transaction cancelled or failed.";
        }
    }, 4000);
}

function setUIElementsToColor(color) {
    ["balance-val", "topup-toggle-btn", "status-badge", "submit-stk", "activateBtn"].forEach(id => {
        const el = document.getElementById(id);
        if(el) el.style.color = id === "balance-val" ? color : (id === "topup-toggle-btn" || id === "submit-stk" || id === "activateBtn" ? "" : color);
        if(el && (id === "topup-toggle-btn" || id === "submit-stk" || id === "activateBtn")) el.style.backgroundColor = color;
    });
    const badge = document.getElementById("status-badge");
    const actBtn = document.getElementById("activateBtn");
    badge.textContent = "INACTIVE";
    actBtn.textContent = "Top up to run";
    actBtn.disabled = true;

    const liveDot = document.getElementById("live-dot");
    if (liveDot) {
        liveDot.className = "live-dot red";
    }
}

async function updateUI() {
    if (!storage.deviceId || !storage.deviceId.includes("@")) {
    return "NONE";
    }
    try {
        const res = await fetch(`${SERVER_URL}/api/v1/status?device_id=${storage.deviceId}`);
        if (!res.ok) return "NONE";
        const data = await res.json();
        document.getElementById("online-users").textContent = data.online_users ?? 0;
        const t = data.token_balance || 0;
        
        document.getElementById("balance-val").textContent = t; 
        let color = t === 0 ? "#991b1b" : (t < 4 ? "#FFBF00" : "rgb(62, 207, 142)");
        
        ["balance-val", "topup-toggle-btn", "status-badge", "submit-stk", "activateBtn"].forEach(id => {
            const el = document.getElementById(id);
            if(el) el.style.color = id === "balance-val" ? color : (id === "topup-toggle-btn" || id === "submit-stk" || id === "activateBtn" ? "" : color);
            if(el && (id === "topup-toggle-btn" || id === "submit-stk" || id === "activateBtn")) el.style.backgroundColor = color;
        });

        const badge = document.getElementById("status-badge");
        const actBtn = document.getElementById("activateBtn");
        const liveDot = document.getElementById("live-dot");
        if (t === 0) {
            badge.textContent = "INACTIVE";
            actBtn.textContent = "Top up to run";
            actBtn.disabled = true;

            liveDot.className = "live-dot red";
        } 
        else if (t < 4){
            badge.textContent = "Monitoring...";
            actBtn.textContent = "Running";
            actBtn.disabled = false;

            liveDot.className = "live-dot yellow"
        }
        else {
            badge.textContent = "ACTIVE";
            actBtn.textContent = "Running";
            actBtn.disabled = false;
            
            liveDot.className = "live-dot green"

        }

        return data.latest_payment_status || "NONE";

    } catch (err) { 
        console.error("UI Update Failed:", err); 
        return "NONE";
    }
}