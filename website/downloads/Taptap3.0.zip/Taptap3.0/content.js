// CONTENT.JS
const SERVER_URL = "https://license-server-lewp.onrender.com";

let alarmInterval = null;
let isSpeakingOrPlaying = false;
let userHasInteracted = false;

// 1. Interaction tracking for audio
function unlockAudio() {
    userHasInteracted = true;
    console.log("Audio Unlocked: User interaction detected.");
    document.removeEventListener('click', unlockAudio);
    document.removeEventListener('keydown', unlockAudio);
}
document.addEventListener('click', unlockAudio);
document.addEventListener('keydown', unlockAudio);

// 2. Messaging Wrapper
function safeSendMessage(msg) {
    return new Promise((resolve) => {
        if (!chrome.runtime?.id) { 
            console.warn("Runtime invalid, waiting for reload...");
            setTimeout(() => location.reload(), 2000); 
            return; 
        }
        chrome.runtime.sendMessage(msg, (response) => {
            if (chrome.runtime.lastError) {
                setTimeout(() => resolve(safeSendMessage(msg)), 1000);
            } else {
                resolve(response);
            }
        });
    });
}

// -----------------------------
// Heartbeat
// -----------------------------
async function sendHeartbeat() {

    try {

        const store = await chrome.storage.local.get("deviceId");

        if (!store.deviceId)
            return;

        await fetch(`${SERVER_URL}/api/v1/heartbeat`, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({

                device_id: store.deviceId

            })

        });

    } catch (err) {
    if (
        err.message &&
        err.message.includes("Extension context invalidated")
    ) {
        return;
    }

    console.error("Heartbeat failed:", err);
}

    }

// -----------------------------
// Independent Heartbeat
// -----------------------------

// Send one immediately
sendHeartbeat();

// Continue every 2 minutes
setInterval(() => {
    sendHeartbeat();
}, 120000);
// 3. Stable Semantic Targeting
function getStableElement(labelText) {
    const items = document.querySelectorAll('.item');
    for (const item of items) {
        const left = item.querySelector('.left');
        if (left && left.textContent.includes(labelText)) {
            return item.querySelector('.right');
        }
    }
    return null;
}

// 4. Audio Loop
function startAlarmLoop() {

    if (alarmInterval) return;

    const playAlerts = () => {

        if (!userHasInteracted) {
            console.warn("Alarm silent: Waiting for user click on page...");
            return;
        }

        if (isSpeakingOrPlaying) return;

        isSpeakingOrPlaying = true;

        const audio = new Audio(chrome.runtime.getURL("alarm.mp3"));

        audio.play()
            .then(() => {
                audio.onended = () => {
                    isSpeakingOrPlaying = false;
                    audio.remove();
                };
            })
            .catch((err) => {
                console.error("Audio playback error:", err);
                isSpeakingOrPlaying = false;
            });

    };

    playAlerts();

    alarmInterval = setInterval(playAlerts, 8000);

    // Safety timeout
    setTimeout(() => {

        if (alarmInterval) {

            clearInterval(alarmInterval);
            alarmInterval = null;

            console.log("Alarm automatically stopped after 60 seconds.");

        }

    }, 60000);

}


// 5. Monitoring Logic

let cachedLabels = null;

async function checkForTargetPopup() {

    console.log("Observer triggered: Checking DOM...");

    if (!chrome.runtime?.id) return;

    try {

        const store = await chrome.storage.local.get("deviceId");

        if (!store.deviceId) return;

        if (!cachedLabels) {

            const ruleData = await safeSendMessage({
                action: "FETCH_RULES"
            });

            cachedLabels = ruleData.labels || {
                orderLabel: "Order Number",
                timeLabel: "Create Time"
            };

        }

        const orderEl = getStableElement(cachedLabels.orderLabel);
        const timeEl = getStableElement(cachedLabels.timeLabel);

        if (!orderEl || !timeEl)
            return;

        const orderNumber = orderEl.textContent.trim();
        const fullTime = timeEl.textContent.trim();

        //
        // Ignore DOM placeholders while the page is still updating
        //

        if (!/^\d+$/.test(orderNumber)) {
            return;
        }

        //
        // Require a proper HH:MM:SS somewhere in the text
        //

        const timeMatch = fullTime.match(/\d{2}:\d{2}:\d{2}/);

        if (!timeMatch) {
            return;
        }

        const timeOnly = timeMatch[0].replace(/:/g,"")

        const txnId = `${orderNumber}_${timeOnly}`;

        const processedData =
            await chrome.storage.local.get("processed_orders");

        const processedOrders =
            processedData.processed_orders || [];

        if (processedOrders.includes(txnId)) {

            if (alarmInterval) {

                clearInterval(alarmInterval);
                alarmInterval = null;

            }

            return;

        }

        console.log("New transaction detected:", txnId);

        startAlarmLoop();

        const chargeRes =
            await safeSendMessage({

                action: "CONSUME_TOKEN_SIGNAL",

                payload: {
                    txn_id: txnId,
                    device_id: store.deviceId
                }

            });

        if (
            chargeRes &&
            (chargeRes.success ||
             chargeRes.message === "Already paid")
        ) {

            processedOrders.push(txnId);

            await chrome.storage.local.set({
                processed_orders: processedOrders
            });

            if (alarmInterval) {

                clearInterval(alarmInterval);
                alarmInterval = null;

            }

        }

    }
    catch (err) {

        if (
            err.message &&
            !err.message.includes("Extension context invalidated")
        ) {

            console.error("Monitor Error:", err);

        }

    }

}

// 6. Init: Use MutationObserver only
const observer = new MutationObserver(() => checkForTargetPopup());
observer.observe(document.body, { childList: true, subtree: true, characterData: true });

// Run once on load
checkForTargetPopup();
// Keep user online while page is open
sendHeartbeat();
setInterval(sendHeartbeat, 120000);